java
list of datatype
integer;
String;
double;
float;
char;
boolean;

Primitive type java
int; float; double; boolean; string


int number = 1;
html
list of datatype
let;
var;
const

Primitive type html
string, number, boolean, null, undefined, symbol
reference datatype
object, array, function

declaring a variable
let name = "12";
let number = "12";

operators
Arithmetic (+/*-%)
comparison(==,===,!=,<>,<=,>=)
let a==1;
let b==2;
a==b

logical(&&,,||,!)

control structures
conditions(if, else if, else, switch)
loops(while, for, do...while, for...in, for...of)
functions
functions myfunction(param1, param2){
//code
}